# G3B1_GradedProject4
Employee Management RestApi based Web Application

Employee-Management-Rest-Api contains the project code
screenshot folder contains screenshots of different functions
